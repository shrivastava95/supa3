from .discriminative_reranking_task import DiscriminativeRerankingNMTTask


__all__ = [
    "DiscriminativeRerankingNMTTask",
]
